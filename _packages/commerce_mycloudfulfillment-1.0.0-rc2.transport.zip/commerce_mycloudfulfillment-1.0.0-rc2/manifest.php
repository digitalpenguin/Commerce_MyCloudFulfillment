<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'MyCloud Fulfillment for Commerce
------------------------

Commerce_MyCloudFulfillment integrates the MyCloudFulfillment API.

',
    'changelog' => 'MyCloudFulfillment for Commerce 1.0.0-rc2
---------------------------------
Released on 16/03/2021

- Changed how item pricing is sent to API
- Fixed assets not being packaged

MyCloudFulfillment for Commerce 1.0.0-rc1
---------------------------------
Released on 25/02/2021

- First release candidate
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c2db319a7421397893d7a09a0dc3c2c3',
      'native_key' => 'commerce_mycloudfulfillment',
      'filename' => 'modNamespace/9df6061307f8530170b8fa9d180ed4b9.vehicle',
      'namespace' => 'commerce_mycloudfulfillment',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '392af54990d686a0ff4dfe74efcadd63',
      'native_key' => '392af54990d686a0ff4dfe74efcadd63',
      'filename' => 'xPDOFileVehicle/9064abf2c847590b6bbb46b44b851d54.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '35d667b6ac894cdc172a05174fb0fdc1',
      'native_key' => '35d667b6ac894cdc172a05174fb0fdc1',
      'filename' => 'xPDOFileVehicle/d58f6654de9ac1bea7a843bc7f92302f.vehicle',
    ),
  ),
);