<?php

$xpdo_meta_map = array (
  'comShippingMethod' => 
  array (
    0 => 'MyCloudFulfillmentShippingMethod',
  ),
  'comOrderShipment' => 
  array (
    0 => 'MyCloudFulfillmentOrderShipment',
  ),
);