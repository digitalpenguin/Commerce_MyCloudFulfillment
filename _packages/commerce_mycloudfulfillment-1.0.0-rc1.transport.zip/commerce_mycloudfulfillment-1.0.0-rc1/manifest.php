<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'MyCloud Fulfillment for Commerce
------------------------

Commerce_MyCloudFulfillment integrates the MyCloudFulfillment API.

',
    'changelog' => 'MyCloudFulfillment for Commerce 1.0.0-rc1
---------------------------------
Released on 25/02/2021

- First release candidate
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f3d82faa584ec3aa2ed49e3a1b0b6892',
      'native_key' => 'commerce_mycloudfulfillment',
      'filename' => 'modNamespace/c078350f5d944bea6967a38b04709cbc.vehicle',
      'namespace' => 'commerce_mycloudfulfillment',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'addc92ec456bfda453842aa041a6868c',
      'native_key' => 'addc92ec456bfda453842aa041a6868c',
      'filename' => 'xPDOFileVehicle/36c8a48d7582ef93d84e4d5940a1e39f.vehicle',
    ),
  ),
);